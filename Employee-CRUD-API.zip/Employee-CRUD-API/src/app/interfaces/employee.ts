export interface IEmployee {
    id?: number,
    name: string,
    email: string,
    phone: string,
    age: number,
    salary: number
}