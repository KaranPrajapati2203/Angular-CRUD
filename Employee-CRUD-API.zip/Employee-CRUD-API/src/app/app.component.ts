import { Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Employee-CRUD-API';
  router = inject(Router);
  
  Logout() {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('token');
      // sessionStorage.removeItem('token');
      console.log('User logged out');
      this.router.navigate(['/login']); 
    }
  }

}
