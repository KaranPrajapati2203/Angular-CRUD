import { HttpInterceptorFn, HttpEvent, HttpRequest, HttpHandler } from '@angular/common/http';

// export const tokenHttpIntercepter: HttpInterceptorFn = (req, next) => {
//     // localStorage:Storage;
//     const token = localStorage.getItem("token");
//     req = req.clone({
//         setHeaders: {
//             // 'Authorization': 'Bearer ' + token
//             'Authorization': `Bearer ${token}`

//         }
//     })
//     return next(req);
// }
export const tokenHttpIntercepter: HttpInterceptorFn = (req, next) => {
    let token = '';

    // Check if window and localStorage are available
    if (typeof window !== 'undefined' && localStorage) {
        token = localStorage.getItem("token") || '';
    }

    if (token) {
        req = req.clone({
            setHeaders: {
                'Authorization': `Bearer ${token}`
            }
        });
    }

    return next(req);
};