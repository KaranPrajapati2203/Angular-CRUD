import { Component, inject } from '@angular/core';
import { IEmployee } from '../../interfaces/employee';
import { HttpService } from '../../services/http.service';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent {
  employeeList: IEmployee[] = [];
  httpService = inject(HttpService);
  router = inject(Router);
  ngOnInit() {
    this.httpService.getAllEmployees().subscribe((result: any) => {
      this.employeeList = result;
      // console.log(this.employeeList);
    })
  }
  viewEmployee(employee: IEmployee): void {
    console.log('Viewing employee', employee);
  }

  editEmployee(id: number | undefined): void {
    console.log('Editing employee', id);
    this.router.navigateByUrl("/employee/" + id);
  }

  deleteEmployee(id: number | undefined): void {
    if (id === undefined) {
      console.error('Cannot delete employee: ID is undefined');
      return;
    }
    this.httpService.deleteEmployee(id).subscribe(() => {
      console.log("employee deleted successfully");
      this.employeeList = this.employeeList.filter(x => x.id != id);
    })
    console.log("delete called for " + id)
  }

  addEmployee() {
    console.log("Employee Added ")
  }

}
