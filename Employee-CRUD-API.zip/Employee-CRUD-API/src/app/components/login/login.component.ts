import { Component, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { HttpService } from '../../services/http.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 

  builder = inject(FormBuilder);
  httpService = inject(HttpService);
  router = inject(Router);
  LoginForm = this.builder.group({
    email: ['', Validators.required],
    password: ['', Validators.required]
  })
  OnLogin() {
    debugger;
    const email = this.LoginForm.value.email!;
    const password = this.LoginForm.value.password!;
    this.httpService.login(email, password).subscribe((result: any) => {
      console.log(result);
      localStorage.setItem("token", result.token);
      this.router.navigateByUrl("employee-list");
    })
    console.log("login successful!!")
  }
}
