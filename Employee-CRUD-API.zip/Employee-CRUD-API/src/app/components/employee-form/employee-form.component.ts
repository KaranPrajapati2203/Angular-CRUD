import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpService } from '../../services/http.service';
import { IEmployee } from '../../interfaces/employee';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, CommonModule],
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit {
  employeeForm!: FormGroup;
  httpService = inject(HttpService);
  router = inject(Router);
  routes = inject(ActivatedRoute)
  employeeId!: number;
  isEdit = false;
  constructor(private fb: FormBuilder) { }

  // ngOnInit(): void {
  //   this.employeeId = this.routes.params['id'];
  //   if (this.employeeId) {
  //     this.isEdit = true;
  //   }
  //   this.employeeForm = this.fb.group({
  //     name: ['', Validators.required],
  //     email: ['', [Validators.required, Validators.email]],
  //     phone: ['', Validators.required],
  //     age: ['', [Validators.required, Validators.min(18)]],
  //     salary: ['', Validators.required]
  //   });
  // }

  ngOnInit(): void {
    this.routes.params.subscribe((params: { [x: string]: number; }) => {
      this.employeeId = params['id'];
      if (this.employeeId) {
        this.isEdit = true;
        // Fetch and populate the form with employee data if it's an edit
        this.httpService.getEmployee(this.employeeId).subscribe((employee: IEmployee) => {
          this.employeeForm.patchValue(employee);
        });
        console.log('edited');
      }
    });

    this.employeeForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      age: ['', [Validators.required, Validators.min(18)]],
      salary: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.employeeForm.valid) {
      console.log('Form Submitted', this.employeeForm.value);
      const employee: IEmployee = {
        name: this.employeeForm.value.name!,
        age: this.employeeForm.value.age!,
        email: this.employeeForm.value.email!,
        phone: this.employeeForm.value.phone!,
        salary: this.employeeForm.value.salary!,
      }
      if (this.isEdit) {
        this.httpService.updateEmployee(this.employeeId, employee).subscribe((result: any) => {
          console.log("update success");
          this.router.navigateByUrl("/");
        })
      } else {
        this.httpService.createEmployee(employee).subscribe((result: any) => {
          console.log("success");
          this.router.navigateByUrl("/");
        })
      }
    }
  }
}
